package com.netflix.ribbon.api;

public class RibbonGateway {
}
