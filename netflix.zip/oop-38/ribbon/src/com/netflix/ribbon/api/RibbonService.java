package com.netflix.ribbon.api;

import com.netflix.ribbon.config.*;

public class RibbonService {
}
