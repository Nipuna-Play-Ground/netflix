package com.netflix.ribbon.config;

public class RibbonConfig {
}
