package com.netflix.ribbon.config;

import com.netflix.spring_security.api.*;

public class RibbonSecurity {
    SecurityFilterChain securityFilterChain;
    Decoder decoder;
}
