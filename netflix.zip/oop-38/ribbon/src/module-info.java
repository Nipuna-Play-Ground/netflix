module com.netflix.ribbon {
    exports com.netflix.ribbon.api;
    requires com.netflix.spring_security;
}