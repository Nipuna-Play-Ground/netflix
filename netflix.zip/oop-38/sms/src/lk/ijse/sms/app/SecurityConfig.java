package lk.ijse.sms.app;

import com.netflix.spring_security.api.*;

public class SecurityConfig {
    SecurityConfig securityConfig;
    Decoder decoder;
}
