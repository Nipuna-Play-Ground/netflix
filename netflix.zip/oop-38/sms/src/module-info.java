module lk.ijse.sms {
    requires com.netflix.zuul;
    requires com.netflix.ribbon;
    requires com.netflix.spring_security;
}