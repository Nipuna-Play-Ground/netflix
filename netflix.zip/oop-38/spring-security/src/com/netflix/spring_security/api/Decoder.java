package com.netflix.spring_security.api;

public class Decoder {
}
