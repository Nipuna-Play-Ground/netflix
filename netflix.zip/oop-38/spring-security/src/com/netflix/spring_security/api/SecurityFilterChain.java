package com.netflix.spring_security.api;

import com.netflix.spring_security.config.MethodSecurity;
import com.netflix.spring_security.util.*;

public class SecurityFilterChain {
}
