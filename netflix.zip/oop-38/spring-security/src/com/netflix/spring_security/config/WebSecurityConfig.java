package com.netflix.spring_security.config;

public class WebSecurityConfig {
}
