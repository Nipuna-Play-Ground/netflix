package com.netflix.spring_security.util;

public class PostAuth {
}
