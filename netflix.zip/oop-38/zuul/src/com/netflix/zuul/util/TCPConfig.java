package com.netflix.zuul.util;

import com.netflix.ribbon.api.*;

public class TCPConfig {
    RibbonService ribbonService;
    RibbonGateway ribbonGateway;
    
}
