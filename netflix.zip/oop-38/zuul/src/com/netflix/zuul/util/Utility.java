package com.netflix.zuul.util;

public class Utility {
}
