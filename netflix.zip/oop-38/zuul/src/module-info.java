module com.netflix.zuul {
    exports com.netflix.zuul.service;
    requires com.netflix.ribbon;
}